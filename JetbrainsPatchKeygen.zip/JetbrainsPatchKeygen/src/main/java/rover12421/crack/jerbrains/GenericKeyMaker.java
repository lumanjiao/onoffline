package com.rover12421.crack.jerbrains;

import java.math.BigInteger;
import java.util.Random;
import java.util.zip.CRC32;

/**
 * Created by rover12421 on 11/18/14.
 */
public class GenericKeyMaker {

    public static final int LICENSETYPE_COMMERCIAL = 0;
    public static final int LICENSETYPE_NON_COMMERCIAL = 1;
    public static final int LICENSETYPE_SITE = 2;
    public static final int LICENSETYPE_OPENSOURCE = 3;
    public static final int LICENSETYPE_PERSONAL = 4;
    public static final int LICENSETYPE_YEARACADEMIC = 5;
    public static final int LICENSETYPE_CLASSROOM = 6;
    public static final int LICENSETYPE_FLOATING = 7;

    public static final int PRODUCTID_IDEA = 1;
    public static final int PRODUCTID_RubyMine = 4;
    public static final int PRODUCTID_PyCharm = 5;
    public static final int PRODUCTID_WebStorm = 6;
    public static final int PRODUCTID_PhpStorm = 7;
    public static final int PRODUCTID_AppCode = 8;
    public static final int PRODUCTID_DBIDE = 9;
    public static final int PRODUCTID_CLION = 10;

    private Random random = new Random();

    private String getLicenseId() {
        return String.format("D%sT", Integer.toString(random.nextInt(90000) + 10000));
    }
   private short getCRC(String s, int i, byte bytes[])
    {
        CRC32 crc32 = new CRC32();
        if (s != null)
        {
            for (int j = 0; j < s.length(); j++)
            {
                char c = s.charAt(j);
                crc32.update(c);
            }
        }
        crc32.update(i);
        crc32.update(i >> 8);
        crc32.update(i >> 16);
        crc32.update(i >> 24);
        for (int k = 0; k < bytes.length - 2; k++)
        {
            byte byte0 = bytes[k];
            crc32.update(byte0);
        }
        return (short) (int) crc32.getValue();
    }

    private byte[] generateKeyBytes14(int licenseType, int productId,
                                      int minorVersion, int majorVersion,
                                      String userName, int customerId) {
        byte[] keyBytes = new byte[14];
        keyBytes[0] = (byte)((licenseType << 4) + (productId & 0xFF));
        keyBytes[1] = (byte)((minorVersion << 4) + (majorVersion & 0xFF));
        long time = System.currentTimeMillis() >> 16;
        keyBytes[2] = (byte)(int)(time & 0xFF);
        keyBytes[3] = (byte)(int)(time >> 8 & 0xFF);
        keyBytes[4] = (byte)(int)(time >> 16 & 0xFF);
        keyBytes[5] = (byte)(int)(time >> 24 & 0xFF);
        long timeDiff = Long.MAX_VALUE;
        keyBytes[6] = (byte)(int)(timeDiff & 0xFF);
        keyBytes[7] = (byte)(int)(timeDiff >> 8 & 0xFF);
        keyBytes[8] = 0;
        keyBytes[9] = 1;
        keyBytes[10] = 2;
        keyBytes[11] = 3;

        int crc32 = getCRC(userName, customerId, keyBytes);
        keyBytes[12] = (byte)(crc32 & 0xFF);
        keyBytes[13] = (byte)(crc32 >> 8 & 0xFF);

        return keyBytes;
    }

    private byte[] generateKeyBytes12(int licenseType, int productId,
                                    int minorVersion, int majorVersion,
                                    String userName, int customerId) {
        byte[] keyBytes = new byte[12];
        keyBytes[0] = (byte)((licenseType << 4) + (productId & 0xFF));
        keyBytes[1] = (byte)((minorVersion << 4) + (majorVersion & 0xFF));
        long time = System.currentTimeMillis() >> 16;
        keyBytes[2] = (byte)(int)(time & 0xFF);
        keyBytes[3] = (byte)(int)(time >> 8 & 0xFF);
        keyBytes[4] = (byte)(int)(time >> 16 & 0xFF);
        keyBytes[5] = (byte)(int)(time >> 24 & 0xFF);
        long timeDiff = Long.MAX_VALUE;
        keyBytes[6] = (byte)(int)(timeDiff & 0xFF);
        keyBytes[7] = (byte)(int)(timeDiff >> 8 & 0xFF);
        keyBytes[8] = 105;
        keyBytes[9] = -59;

        int crc32 = getCRC(userName, customerId, keyBytes);
        keyBytes[10] = (byte)(crc32 & 0xFF);
        keyBytes[11] = (byte)(crc32 >> 8 & 0xFF);

        return keyBytes;
    }

    /**
     * @param biginteger
     * @return String
     */
    public static String encodeGroups(BigInteger biginteger)
    {
        BigInteger beginner1 = BigInteger.valueOf(0x39aa400L);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; biginteger.compareTo(BigInteger.ZERO) != 0; i++)
        {
            int j = biginteger.mod(beginner1).intValue();
            String s1 = encodeGroup(j);
            if (i > 0)
            {
                sb.append("-");
            }
            sb.append(s1);
            biginteger = biginteger.divide(beginner1);
        }
        return sb.toString();
    }

    /**
     * @param i
     * @return
     */
         public static String encodeGroup(int i)
    {
        StringBuilder sb = new StringBuilder();
        for (int j = 0; j < 5; j++)
        {
            int k = i % 36;
            char c;
            if (k < 10)
            {
                c = (char) (48 + k);
            }
            else
            {
                c = (char) ((65 + k) - 10);
            }
            sb.append(c);
            i /= 36;
        }
        return sb.toString();
    }

    public String generateRSAKey(BigInteger privKey, BigInteger pubKey,
                                 int licenseType, int productId,
                                 int minorVersion, int majorVersion,
                                 String userName) {

        int customerId = random.nextInt(9000) + 1000;
        byte[] keyBytes = generateKeyBytes14(licenseType, productId, minorVersion, majorVersion, userName, customerId);

        RSAEncoder encoder = new RSAEncoder(privKey, pubKey, 64, false);
        String serial = encoder.encode(keyBytes);

//        System.out.println("UsreName : " + userName);
        serial = "===== LICENSE BEGIN =====\n" + customerId + "-" + getLicenseId() + "\n" + serial + "\n===== LICENSE END =====";
        return serial;
    }

//    public String genericPyCharmKey(int minorVersion, int majorVersion, String userName) {
//        BigInteger pubKey = new BigInteger("D57B0596A03949D9A3BB0CD1F7931E405AE27D0E0AF4E562072B487B0DAB7F0874AA982E5383E75FF13D36CA9D8531AC1FA2ED7B11C8858E821C2D5FB48002DD", 16);
//        BigInteger privKey = new BigInteger("406047D02363033D295DB7C0FD8A94DDCD4A6D71B5A622220C8D65DF0DC1409E0BDE26AF66B0AD717406C22FC8BEC3ED88C1B7091BA3443B6BFBA26120DE6A15", 16);
//
//        return generateRSAKey(privKey, pubKey, LICENSETYPE_NON_COMMERCIAL, PRODUCTID_PyCharm, minorVersion, majorVersion, userName);
//    }
//
//    public String genericAppCodeKey(int minorVersion, int majorVersion, String userName) {
//        BigInteger pubKey = new BigInteger("F0DD6995C4BD3223641C79C8608D74F32ED54A8BDAE468EB5AC53F1F1C8925E263F82317356BC73B1C82B520630250212416C99CB39A8B7C2611E35552E166B9", 16);
//        BigInteger privKey = new BigInteger("81B5EAEF61A4B584839C26253781D63243CD4F38E3A74FAD3713B3FB7025978538F10E743456F24BB20D5792BFDCB76DB6162C3D5C77DB7B29906CBFC9114EA5", 16);
//
//        return generateRSAKey(privKey, pubKey, LICENSETYPE_NON_COMMERCIAL, PRODUCTID_AppCode, minorVersion, majorVersion, userName);
//    }
//
//    public String genericPhpStormKey(int minorVersion, int majorVersion, String userName) {
//        BigInteger pubKey = new BigInteger("BB62FBB57F105CD61B47AE2290FCB3CE1179942DE171BEDDF6BAA1A521B9368B735C7C931902EBA8DE6D160711A6ECC40F4A5E766E9FCDEE8A38715DB572AD3D", 16);
//        BigInteger privKey = new BigInteger("7BFADCB153F59E86E69BC1820B4DB72573786E6B00CB824E57AD59BFE915231972746F47C6FBE0D8D88809DA313C1E4BEAD305AD8AFD31AE116ABCB181FF4F21", 16);
//
//        return generateRSAKey(privKey, pubKey, LICENSETYPE_NON_COMMERCIAL, PRODUCTID_PhpStorm, minorVersion, majorVersion, userName);
//    }
//
//    public String genericRubyMineKey(int minorVersion, int majorVersion, String userName) {
//        BigInteger pubKey = new BigInteger("BB62FBB57F105CD61B47AE2290FCB3CE1179942DE171BEDDF6BAA1A521B9368B735C7C931902EBA8DE6D160711A6ECC40F4A5E766E9FCDEE8A38715DB572AD3D", 16);
//        BigInteger privKey = new BigInteger("7BFADCB153F59E86E69BC1820B4DB72573786E6B00CB824E57AD59BFE915231972746F47C6FBE0D8D88809DA313C1E4BEAD305AD8AFD31AE116ABCB181FF4F21", 16);
//
//        return generateRSAKey(privKey, pubKey, LICENSETYPE_NON_COMMERCIAL, PRODUCTID_RubyMine, minorVersion, majorVersion, userName);
//    }
//
//    public String genericWebStormKey(int minorVersion, int majorVersion, String userName) {
//        BigInteger pubKey = new BigInteger("BB62FBB57F105CD61B47AE2290FCB3CE1179942DE171BEDDF6BAA1A521B9368B735C7C931902EBA8DE6D160711A6ECC40F4A5E766E9FCDEE8A38715DB572AD3D", 16);
//        BigInteger privKey = new BigInteger("7BFADCB153F59E86E69BC1820B4DB72573786E6B00CB824E57AD59BFE915231972746F47C6FBE0D8D88809DA313C1E4BEAD305AD8AFD31AE116ABCB181FF4F21", 16);
//
//        return generateRSAKey(privKey, pubKey, LICENSETYPE_NON_COMMERCIAL, PRODUCTID_WebStorm, minorVersion, majorVersion, userName);
//    }
//
//    public String genericClionKey(int minorVersion, int majorVersion, String userName) {
//        BigInteger pubKey = new BigInteger("c4ad4c091e08e5688b81b837506eb84d103fb3b2165f62e61c74b345d28c4a0cd0be2fadf485883d0ddd4e24aab758716027e84d420de525b042a70ff8174031", 16);
//        BigInteger privKey = new BigInteger("6faadd5307e4912c4c993858dfa81da853a3778993be50ceca35505c427138d112d75aa22924e9317270c88b164c31c17c5a43b359f21dabfe923a7482dd7401", 16);
//
//        return generateRSAKey(privKey, pubKey, LICENSETYPE_NON_COMMERCIAL, PRODUCTID_CLION, minorVersion, majorVersion, userName);
//    }

    public String generateNoRSAKey(BigInteger privKey, BigInteger pubKey,
                                 int licenseType, int productId,
                                 int minorVersion, int majorVersion,
                                 String userName) {
        int customerId = random.nextInt(9000) + 1000;
        byte[] keyBytes = generateKeyBytes12(licenseType, productId, minorVersion, majorVersion, userName, customerId);

        BigInteger k0 = new BigInteger(keyBytes);
        BigInteger k1 = k0.modPow(pubKey, privKey);
        String s0 = Integer.toString(customerId);
        String sz = "0";
        while (s0.length() != 5)
        {
            s0 = sz.concat(s0);
        }
        s0 = s0.concat("-");
        String s1 = encodeGroups(k1);
        s0 = s0.concat(s1);
        return s0;
    }

//    public String genericIdeaKey(int minorVersion, int majorVersion, String userName) {
//        BigInteger pubKey = new BigInteger("89126272330128007543578052027888001981", 10);
//        BigInteger privKey = new BigInteger("86f71688cdd2612ca117d1f54bdae029", 16);
//
//        return generateNoRSAKey(privKey, pubKey, LICENSETYPE_NON_COMMERCIAL, PRODUCTID_IDEA, minorVersion, majorVersion, userName);
//    }
}